clc;
clear all;
close all;
%t = 0:0.01:10;
X = input('Enter Input:');
c = xcorr(X);
plot(c)