/*
Write a program that prints a ­Christmas tree:
   /\'
  /  \'
 /    \'
/      \'
--------
  "  "
  "  "
  "  "
Remember to use escape sequences.
*/

public class P2_20 {
    public static void main(String[] args) {
        System.out.print("   /\\'  \n  /  \\'  \n /    \\' \n/      \\'\n");
        System.out.println("--------");
        System.out.println("  \"  \"  ");
        System.out.println("  \"  \"  ");
        System.out.println("  \"  \"  ");
    }
}