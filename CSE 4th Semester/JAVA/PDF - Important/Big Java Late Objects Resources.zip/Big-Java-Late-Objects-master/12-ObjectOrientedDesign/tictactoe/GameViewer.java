package tictactoe;

import javax.swing.JFrame;

public class GameViewer {
    @SuppressWarnings("unused")
    public static void main(String[] args) {
        JFrame frame = new GameFrame();
    }
}