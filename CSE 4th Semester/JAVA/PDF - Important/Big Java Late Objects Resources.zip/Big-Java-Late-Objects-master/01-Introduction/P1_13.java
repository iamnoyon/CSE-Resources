/*
Write a program that prints the United States flag, using * and = characters.
*/

public class P1_13 {
	public static void main(String[] args) {
		System.out.println("|* * * * * * * * * * =========================|");
		System.out.println("| * * * * * * * * *  =========================|");
		System.out.println("| * * * * * * * * *  =========================|");
		System.out.println("| * * * * * * * * *  =========================|");
		System.out.println("| * * * * * * * * *  =========================|");
		System.out.println("| * * * * * * * * *  =========================|");
		System.out.println("|=============================================|");
		System.out.println("|=============================================|");
		System.out.println("|=============================================|");
		System.out.println("|=============================================|");
		System.out.println("|=============================================|");
		System.out.println("|=============================================|");
	}
}