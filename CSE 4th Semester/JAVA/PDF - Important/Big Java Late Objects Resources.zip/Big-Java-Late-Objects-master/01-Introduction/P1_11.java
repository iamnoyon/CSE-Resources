/*
Write a program that prints three items, such as the names of your three best friends
or favorite movies, on three separate lines.
*/

public class P1_11 {
	public static void main(String[] args) {
		System.out.println("Chair");
		System.out.println("Table");
		System.out.println("House");
	}
}