/*
Write a program that prints a poem of your choice. If you don’t have a favorite
poem, search the Internet for “Emily Dickinson” or “e e cummings”.
*/

public class P1_12 {
	public static void main(String[] args) {
		System.out.println("I thought I had forgotten,");
		System.out.println("But it all came back again");
		System.out.println("To-night with the first spring thunder");
		System.out.println("In a rush of rain.");
	}
}