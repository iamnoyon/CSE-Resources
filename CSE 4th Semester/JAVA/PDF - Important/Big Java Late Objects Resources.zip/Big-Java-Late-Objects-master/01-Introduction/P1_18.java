/*
Write a program that prints a two-column list of your friends’ birthdays. In the
first column, print the names of your best friends; in the second column, print their
birthdays.
*/

public class P1_18 {
	public static void main(String[] args) {
		System.out.println("|| Hristo  || 07.02.1994 ||");
		System.out.println("|| Joro    || 22.09.1994 ||");
		System.out.println("|| Tihomir || 18.12.1994 ||");
	}
}