/*
Write a program that prints an animal speaking a greeting,
similar to (but different from) the following:
     /\_/\     -----
    ( ‘ ’ )  / Hello \'
    (  -  ) < Junior |
     | | |   \ Coder!/
    (__|__)    -----
*/

public class P1_10 {
	public static void main(String[] args) {
		System.out.println("          _,\'|             _.-''``-...___..--';)");
        System.out.println("         /_ \\'.      __..-' ,      ,--...--\'\'\'");
        System.out.println("Meoow!  <\\    .`--'''       `     /\'");
        System.out.println("         `-';'               ;   ; ;");
        System.out.println("   __...--''     ___...--_..'  .;.'");
        System.out.println("  (,__....----\'\'\'       (,..--\'\' ");
	}
}