/*
Type in and run the following program:
Then modify the program to show the message “Hello, your name!”.
*/

import javax.swing.JOptionPane;

public class P1_14
{
	public static void main(String[] args)
	{
		JOptionPane.showMessageDialog(null, "Hello, Stilyan!");
	}
}