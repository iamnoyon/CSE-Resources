/*Write a program that prints a face similar to (but different from) the following:
  /////
 +"""""+
(| o o |)
 |  ^  |
 | ‘-’ |
 +-----+
*/

public class P1_07 {
	public static void main(String[] args) {
		System.out.println("  \\|||||/  ");
		System.out.println(" ( ~   ~ ) ");
		System.out.println("@( 0   0 )@");
		System.out.println(" (   C   )");
		System.out.println("  \\ \\_/ /");
		System.out.println("   |___| ");
		System.out.println("   |___| ");
	}
}