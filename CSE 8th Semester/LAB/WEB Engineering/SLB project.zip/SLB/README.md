# SLB
Simple Laravel Bookstore
